﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Task
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ToString());
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindState();
            }
        }
        internal void BindState()
        {
            cmd = new SqlCommand("select stid,stname from state", conn);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "newstate");
            DropStateList.DataSource = ds.Tables["newstate"];
            DropStateList.DataValueField = "stid";
            DropStateList.DataTextField = "stname";
            DropStateList.DataBind();
            DropStateList.Items.Insert(0, "-Select-");
        }

        protected void DropStateList_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select cid,cname from city where stid='" + DropStateList.SelectedValue + "'", conn);
            cmd.Parameters.AddWithValue("@stid", DropStateList.SelectedValue);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "newcity");
            DropCityList.DataSource = ds.Tables["newcity"];
            DropCityList.DataValueField = "cid";
            DropCityList.DataTextField = "cname";
            DropCityList.DataBind();
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select * from emp where cid='" + DropCityList.SelectedValue + "'", conn);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "newemp");
            GridView.DataSource = ds.Tables["newemp"];
            GridView.Visible = true;
            GridView.DataBind();
        }
    }
}